package com.hotel.service;

/**
 * 服务层返回结果包装类
 * @param <T> 返回数据类型
 */
public class ServiceResult<T> {
    private boolean success;
    private String message;
    private T data;
    
    public ServiceResult() {
        this.success = false;
        this.message = "";
        this.data = null;
    }
    
    public ServiceResult(boolean success, String message) {
        this.success = success;
        this.message = message;
        this.data = null;
    }
    
    public ServiceResult(boolean success, String message, T data) {
        this.success = success;
        this.message = message;
        this.data = data;
    }
    
    public static <T> ServiceResult<T> success(String message) {
        return new ServiceResult<>(true, message);
    }
    
    public static <T> ServiceResult<T> success(String message, T data) {
        return new ServiceResult<>(true, message, data);
    }
    
    public static <T> ServiceResult<T> failure(String message) {
        return new ServiceResult<>(false, message);
    }
    
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public T getData() {
        return data;
    }
    
    public void setData(T data) {
        this.data = data;
    }
} 