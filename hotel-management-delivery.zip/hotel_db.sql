/*
 Navicat Premium Data Transfer

 Source Server         : localhost_3306
 Source Server Type    : MySQL
 Source Server Version : 80042 (8.0.42)
 Source Host           : localhost:3306
 Source Schema         : hotel_db

 Target Server Type    : MySQL
 Target Server Version : 80042 (8.0.42)
 File Encoding         : 65001

 Date: 17/06/2025 15:08:32
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for bookings
-- ----------------------------
DROP TABLE IF EXISTS `bookings`;
CREATE TABLE `bookings`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `room_id` int NOT NULL,
  `check_in_date` timestamp NOT NULL,
  `check_out_date` timestamp NOT NULL,
  `total_price` decimal(10, 2) NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL DEFAULT '已预订',
  `booking_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `special_requests` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `guest_count` int NULL DEFAULT 1,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `user_id`(`user_id` ASC) USING BTREE,
  INDEX `room_id`(`room_id` ASC) USING BTREE,
  CONSTRAINT `bookings_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT,
  CONSTRAINT `bookings_ibfk_2` FOREIGN KEY (`room_id`) REFERENCES `rooms` (`id`) ON DELETE CASCADE ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of bookings
-- ----------------------------
INSERT INTO `bookings` VALUES (6, 6, 1, '2025-06-18 00:00:00', '2025-06-26 00:00:00', 2392.00, '已预订', '2025-06-17 15:00:25', '', 1);

-- ----------------------------
-- Table structure for rooms
-- ----------------------------
DROP TABLE IF EXISTS `rooms`;
CREATE TABLE `rooms`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `room_number` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `room_type` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `price` decimal(10, 2) NOT NULL,
  `capacity` int NOT NULL,
  `available` tinyint(1) NULL DEFAULT 1,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL,
  `image_url` varchar(355) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `floor` int NOT NULL,
  `status` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT '可用',
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `room_number`(`room_number` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of rooms
-- ----------------------------
INSERT INTO `rooms` VALUES (1, '101', '标准单人间', 299.00, 1, 1, '舒适的单人间，配备单人床、电视、空调和独立卫浴。', 'https://ts1.tc.mm.bing.net/th/id/R-C.d7c9a322e3193efa4aa83a120636bcd3?rik=RooiU3pwtLpexA&amp;riu=http%3a%2f%2fwww.gdhyjj.com%2fUploadFiles%2fProduct%2f20180531111707372167.jpg&amp;ehk=YEAhCcQjykAvX7Rnt%2bQWeIpj3x43uj8vsPvHAQC%2f8CQ%3d&amp;risl=&amp;pid=ImgRaw&amp;r=0', 1, '可用');
INSERT INTO `rooms` VALUES (2, '102', '标准单人间', 299.00, 1, 1, '舒适的单人间，配备单人床、电视、空调和独立卫浴。', 'https://uimg.huixiaoer.net/86125368/28eded563ea0aa61320dbbde244fa829.jpg', 1, '可用');
INSERT INTO `rooms` VALUES (3, '201', '标准双人间', 399.00, 2, 1, '舒适的双人间，配备双人床、电视、空调和独立卫浴。', 'https://ts1.tc.mm.bing.net/th/id/R-C.075280f901bf03cc8d9885c9f22de050?rik=YxdNYRSFZyvqIg&riu=http%3a%2f%2fwww.xibeishiyouhotel.com%2fuploads%2f211127%2f1_160318_4.jpg&ehk=NjOdgCyFJKc0CpXYgX9hD%2bT8esNFw333jUzzLOzK8Gg%3d&risl=&pid=ImgRaw&r=0', 2, '可用');
INSERT INTO `rooms` VALUES (4, '202', '标准双人间', 399.00, 2, 1, '舒适的双人间，配备双人床、电视、空调和独立卫浴。', 'https://ts1.tc.mm.bing.net/th/id/R-C.075280f901bf03cc8d9885c9f22de050?rik=YxdNYRSFZyvqIg&riu=http%3a%2f%2fwww.xibeishiyouhotel.com%2fuploads%2f211127%2f1_160318_4.jpg&ehk=NjOdgCyFJKc0CpXYgX9hD%2bT8esNFw333jUzzLOzK8Gg%3d&risl=&pid=ImgRaw&r=0', 2, '可用');
INSERT INTO `rooms` VALUES (5, '301', '豪华套房', 699.00, 4, 1, '豪华套房，配备一张大床和一张沙发床、电视、空调、迷你吧和独立卫浴。', 'https://www.hilton.com.cn/file/images/20200508/20200508104659704bAUd7qG.jpg', 3, '可用');
INSERT INTO `rooms` VALUES (6, '302', '总统套房', 1299.00, 4, 1, '最顶级的套房，配备独立客厅、卧室、豪华卫浴和迷你厨房。', 'https://ts1.tc.mm.bing.net/th/id/R-C.1657fae24c2640bc90f28c17e15597e4?rik=LCZx%2fFJXgfGMug&riu=http%3a%2f%2fn.sinaimg.cn%2fsinakd20116%2f300%2fw1620h1080%2f20230210%2fdea3-dc4f95fcbe08381e059a7a8180fbee3d.jpg&ehk=sdzEzNmRcyPc8gNm46YG0cUnySW%2bTYbeu0kXg%2b8HD%2fs%3d&risl=&pid=ImgRaw&r=0', 3, '可用');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `full_name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NOT NULL,
  `phone` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `address` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci NULL DEFAULT NULL,
  `registration_date` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  `is_admin` tinyint(1) NULL DEFAULT 0,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `username`(`username` ASC) USING BTREE,
  UNIQUE INDEX `email`(`email` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_0900_ai_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', '$2a$12$Yyhzhzv19QIzslQLC8W4MOoM1wAj.6qldL6awzlRA.fwKBkc8Ylxe', '系统管理员', 'admin@hotel.com', '13800138033', '酒店管理处', '2025-06-17 01:36:16', 1);
INSERT INTO `users` VALUES (6, '1', '$2a$12$b1qXRVtOgczGE8wqxHUl..bQn90b2YbI1ZIdt/C0iTBJnybbpIfFm', '1', '1@qq.com', '15261031952', '1', '2025-06-17 15:00:01', 0);

SET FOREIGN_KEY_CHECKS = 1;
