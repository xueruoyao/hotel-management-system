package com.hotel.controller;

import com.hotel.model.Booking;
import com.hotel.model.Room;
import com.hotel.model.User;
import com.hotel.service.BookingService;
import com.hotel.service.RoomService;
import com.hotel.service.ServiceResult;
import com.hotel.service.UserService;
import com.hotel.util.SecurityUtil;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/booking")
public class BookingController {

    private final BookingService bookingService;
    private final RoomService roomService;
    private final UserService userService;

    public BookingController(BookingService bookingService, RoomService roomService, UserService userService) {
        this.bookingService = bookingService;
        this.roomService = roomService;
        this.userService = userService;
    }

    @PostMapping("/create")
    public ResponseEntity<Map<String, Object>> createBooking(
            @RequestBody Map<String, Object> bookingData,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(r);
        }

        int userId = (int) session.getAttribute("userId");

        Map<String, String> errors = new HashMap<>();

        Object roomIdObj = bookingData.get("roomId");
        String checkInDate = (String) bookingData.get("checkInDate");
        String checkOutDate = (String) bookingData.get("checkOutDate");
        Object guestCountObj = bookingData.get("guestCount");
        String specialRequests = (String) bookingData.get("specialRequests");

        int rid = 0;
        try {
            if (roomIdObj instanceof Integer) {
                rid = (Integer) roomIdObj;
            } else if (roomIdObj instanceof String) {
                rid = Integer.parseInt((String) roomIdObj);
            } else {
                errors.put("roomId", "无效的房间ID");
            }
        } catch (Exception e) {
            errors.put("roomId", "无效的房间ID");
        }

        Date inDate = null;
        Date outDate = null;
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            inDate = df.parse(checkInDate);
            outDate = df.parse(checkOutDate);
        } catch (ParseException e) {
            errors.put("checkInDate", "无效的日期格式，请使用yyyy-MM-dd格式");
        }

        int gc = 1;
        if (guestCountObj != null) {
            try {
                if (guestCountObj instanceof Integer) {
                    gc = (Integer) guestCountObj;
                } else if (guestCountObj instanceof String) {
                    gc = Integer.parseInt((String) guestCountObj);
                } else {
                    errors.put("guestCount", "无效的客人数量");
                }
                if (gc <= 0) {
                    errors.put("guestCount", "客人数量必须大于0");
                }
            } catch (Exception e) {
                errors.put("guestCount", "无效的客人数量");
            }
        }

        specialRequests = SecurityUtil.sanitizeInput(specialRequests);

        if (!errors.isEmpty()) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        Room room = roomService.getRoomById(rid);
        if (room == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "房间不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(r);
        }

        if (!bookingService.isRoomAvailableForBooking(rid, inDate, outDate)) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "该房间在所选日期已被预订");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        Booking booking = new Booking();
        booking.setUserId(userId);
        booking.setRoomId(rid);
        booking.setCheckInDate(inDate);
        booking.setCheckOutDate(outDate);
        booking.setGuestCount(gc);
        booking.setSpecialRequests(specialRequests);

        ServiceResult<Booking> result = bookingService.createBooking(booking);

        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            Booking b = result.getData();
            if (b.getUser() != null) {
                b.getUser().setPassword(null);
            }
            r.put("success", true);
            r.put("message", result.getMessage());
            r.put("booking", b);
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @GetMapping("/list")
    public ResponseEntity<Map<String, Object>> listBookings(
            @RequestParam(required = false) String id,
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String status,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能查看所有预订");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        List<Booking> bookings = bookingService.getAllBookingsWithDetails();

        if (id != null && !id.trim().isEmpty()) {
            try {
                int bid = Integer.parseInt(id.trim());
                bookings = bookings.stream().filter(b -> b.getId() == bid).collect(Collectors.toList());
            } catch (NumberFormatException e) {
                bookings = new ArrayList<>();
            }
        }

        if (username != null && !username.trim().isEmpty()) {
            String lower = username.trim().toLowerCase();
            bookings = bookings.stream().filter(b ->
                    b.getUser() != null
                            && b.getUser().getUsername() != null
                            && b.getUser().getUsername().toLowerCase().contains(lower)
            ).collect(Collectors.toList());
        }

        if (status != null && !status.trim().isEmpty()) {
            bookings = bookings.stream().filter(b -> status.equals(b.getStatus())).collect(Collectors.toList());
        }

        bookings.forEach(b -> {
            if (b.getUser() != null) {
                b.getUser().setPassword(null);
            }
        });

        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("bookings", bookings);
        return ResponseEntity.ok(r);
    }

    @GetMapping("/userBookings")
    public ResponseEntity<Map<String, Object>> getUserBookings(
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String roomType,
            @RequestParam(required = false) String dateRange,
            @RequestParam(required = false) String page,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(r);
        }

        int userId = (int) session.getAttribute("userId");

        int p = 1;
        if (page != null && !page.isEmpty()) {
            try {
                p = Integer.parseInt(page);
                if (p < 1) p = 1;
            } catch (Exception ignored) {
            }
        }

        List<Booking> bookings = bookingService.getUserBookingsWithDetails(userId);

        if (status != null && !status.isEmpty()) {
            bookings = bookings.stream().filter(b -> status.equals(b.getStatus())).collect(Collectors.toList());
        }
        if (roomType != null && !roomType.isEmpty()) {
            bookings = bookings.stream()
                    .filter(b -> b.getRoom() != null && roomType.equals(b.getRoom().getRoomType()))
                    .collect(Collectors.toList());
        }
        if (dateRange != null && !dateRange.isEmpty()) {
            Date now = new Date();
            Calendar cal = Calendar.getInstance();
            switch (dateRange) {
                case "upcoming":
                    bookings = bookings.stream()
                            .filter(b -> b.getCheckInDate() != null && b.getCheckInDate().compareTo(now) >= 0)
                            .collect(Collectors.toList());
                    break;
                case "past":
                    bookings = bookings.stream()
                            .filter(b -> b.getCheckOutDate() != null && b.getCheckOutDate().compareTo(now) < 0)
                            .collect(Collectors.toList());
                    break;
                case "month":
                    cal.add(Calendar.MONTH, -1);
                    Date oneMonthAgo = cal.getTime();
                    bookings = bookings.stream()
                            .filter(b -> b.getBookingDate() != null && b.getBookingDate().compareTo(oneMonthAgo) >= 0)
                            .collect(Collectors.toList());
                    break;
                case "halfyear":
                    cal.add(Calendar.MONTH, -6);
                    Date sixMonthsAgo = cal.getTime();
                    bookings = bookings.stream()
                            .filter(b -> b.getBookingDate() != null && b.getBookingDate().compareTo(sixMonthsAgo) >= 0)
                            .collect(Collectors.toList());
                    break;
            }
        }

        int pageSize = 10;
        int totalItems = bookings.size();
        int totalPages = (int) Math.ceil((double) totalItems / pageSize);
        if (p > totalPages && totalPages > 0) p = totalPages;
        int from = (p - 1) * pageSize;
        int to = Math.min(from + pageSize, totalItems);
        List<Booking> paged = from < totalItems ? bookings.subList(from, to) : new ArrayList<>();

        paged.forEach(b -> {
            if (b.getUser() != null) {
                b.getUser().setPassword(null);
            }
        });

        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("bookings", paged);
        r.put("currentPage", p);
        r.put("totalPages", totalPages);
        r.put("totalItems", totalItems);
        return ResponseEntity.ok(r);
    }

    @GetMapping("/detail")
    public ResponseEntity<Map<String, Object>> getBookingDetail(@RequestParam("id") String id, HttpSession session) {
        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(r);
        }

        int userId = (int) session.getAttribute("userId");
        boolean isAdmin = session.getAttribute("isAdmin") != null && (boolean) session.getAttribute("isAdmin");

        int bookingId;
        try {
            bookingId = Integer.parseInt(id);
        } catch (Exception e) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "无效的预订ID");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        Booking booking = bookingService.getBookingById(bookingId);
        if (booking == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "预订不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(r);
        }

        if (!isAdmin && booking.getUserId() != userId) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "您没有权限查看此预订");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        Room room = roomService.getRoomById(booking.getRoomId());
        booking.setRoom(room);
        User user = userService.getUserById(booking.getUserId());
        if (user != null) user.setPassword(null);
        booking.setUser(user);

        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("booking", booking);
        return ResponseEntity.ok(r);
    }

    @PostMapping("/cancel")
    public ResponseEntity<Map<String, Object>> cancelBooking(@RequestBody Map<String, String> requestData, HttpSession session) {
        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(r);
        }

        int userId = (int) session.getAttribute("userId");
        boolean isAdmin = session.getAttribute("isAdmin") != null && (boolean) session.getAttribute("isAdmin");

        String id = requestData.get("id");
        int bookingId;
        try {
            bookingId = Integer.parseInt(id);
        } catch (Exception e) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "无效的预订ID");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        Booking booking = bookingService.getBookingById(bookingId);
        if (booking == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "预订不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(r);
        }

        if (!isAdmin && booking.getUserId() != userId) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "您没有权限取消此预订");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        ServiceResult<Boolean> result = bookingService.cancelBooking(bookingId);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @PostMapping("/checkIn")
    public ResponseEntity<Map<String, Object>> checkIn(@RequestParam("id") String id, HttpSession session) {
        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能办理入住");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        int bookingId;
        try {
            bookingId = Integer.parseInt(id);
        } catch (Exception e) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "无效的预订ID");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        ServiceResult<Boolean> result = bookingService.checkIn(bookingId);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @PostMapping("/checkOut")
    public ResponseEntity<Map<String, Object>> checkOut(@RequestParam("id") String id, HttpSession session) {
        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能办理退房");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        int bookingId;
        try {
            bookingId = Integer.parseInt(id);
        } catch (Exception e) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "无效的预订ID");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        ServiceResult<Boolean> result = bookingService.checkOut(bookingId);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @PostMapping("/delete")
    public ResponseEntity<Map<String, Object>> deleteBooking(@RequestParam("id") String id, HttpSession session) {
        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能删除预订");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        int bookingId;
        try {
            bookingId = Integer.parseInt(id);
        } catch (Exception e) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "无效的预订ID");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        ServiceResult<Boolean> result = bookingService.deleteBooking(bookingId);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @PostMapping("/update")
    public ResponseEntity<Map<String, Object>> updateBooking(
            @RequestParam("id") String id,
            @RequestParam("userId") String userId,
            @RequestParam("roomId") String roomId,
            @RequestParam("checkInDate") String checkInDate,
            @RequestParam("checkOutDate") String checkOutDate,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String specialRequests,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "权限不足");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        Map<String, String> errors = new HashMap<>();

        int bid;
        int uid;
        int rid;
        try {
            bid = Integer.parseInt(id);
        } catch (Exception e) {
            bid = 0;
            errors.put("id", "无效的预订ID");
        }
        try {
            uid = Integer.parseInt(userId);
        } catch (Exception e) {
            uid = 0;
            errors.put("userId", "无效的用户ID");
        }
        try {
            rid = Integer.parseInt(roomId);
        } catch (Exception e) {
            rid = 0;
            errors.put("roomId", "无效的房间ID");
        }

        Date inDate = null;
        Date outDate = null;
        try {
            SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
            inDate = df.parse(checkInDate);
            outDate = df.parse(checkOutDate);
        } catch (ParseException e) {
            errors.put("checkInDate", "无效的日期格式，请使用yyyy-MM-dd格式");
        }

        if (!errors.isEmpty()) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        Booking existing = bookingService.getBookingById(bid);
        if (existing == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "订单不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(r);
        }

        existing.setUserId(uid);
        existing.setRoomId(rid);
        existing.setCheckInDate(inDate);
        existing.setCheckOutDate(outDate);
        if (status != null && !status.isEmpty()) {
            existing.setStatus(status);
        }
        specialRequests = SecurityUtil.sanitizeInput(specialRequests);
        if (specialRequests != null) {
            existing.setSpecialRequests(specialRequests);
        }

        ServiceResult<Boolean> result = bookingService.updateBooking(existing);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", "订单更新成功");
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @GetMapping("/stats")
    public ResponseEntity<Map<String, Object>> getBookingStats(HttpSession session) {
        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(r);
        }

        int userId = (int) session.getAttribute("userId");
        boolean isAdmin = session.getAttribute("isAdmin") != null && (boolean) session.getAttribute("isAdmin");

        Map<String, Object> stats = new HashMap<>();

        if (isAdmin) {
            List<Booking> all = bookingService.getAllBookings();
            stats.put("totalBookings", all.size());

            long pending = all.stream().filter(b -> "已预订".equals(b.getStatus())).count();
            long checkedIn = all.stream().filter(b -> "已入住".equals(b.getStatus())).count();
            long completed = all.stream().filter(b -> "已退房".equals(b.getStatus())).count();
            long cancelled = all.stream().filter(b -> "已取消".equals(b.getStatus())).count();

            Map<String, Long> statusStats = new HashMap<>();
            statusStats.put("pending", pending);
            statusStats.put("checkedIn", checkedIn);
            statusStats.put("completed", completed);
            statusStats.put("cancelled", cancelled);
            stats.put("statusStats", statusStats);

            Map<String, Long> monthlyStats = all.stream().filter(b -> b.getBookingDate() != null)
                    .collect(Collectors.groupingBy(b -> {
                        Calendar cal = Calendar.getInstance();
                        cal.setTime(b.getBookingDate());
                        return cal.get(Calendar.YEAR) + "-" + (cal.get(Calendar.MONTH) + 1);
                    }, Collectors.counting()));
            stats.put("monthlyStats", monthlyStats);

            Map<Integer, Long> roomTypeStats = all.stream()
                    .filter(b -> !"已取消".equals(b.getStatus()))
                    .collect(Collectors.groupingBy(Booking::getRoomId, Collectors.counting()));
            stats.put("roomTypeStats", roomTypeStats);
        } else {
            List<Booking> userBookings = bookingService.getUserBookings(userId);
            stats.put("totalBookings", userBookings.size());

            long pending = userBookings.stream().filter(b -> "已预订".equals(b.getStatus())).count();
            long checkedIn = userBookings.stream().filter(b -> "已入住".equals(b.getStatus())).count();
            long completed = userBookings.stream().filter(b -> "已退房".equals(b.getStatus())).count();
            long cancelled = userBookings.stream().filter(b -> "已取消".equals(b.getStatus())).count();

            Map<String, Long> statusStats = new HashMap<>();
            statusStats.put("pending", pending);
            statusStats.put("checkedIn", checkedIn);
            statusStats.put("completed", completed);
            statusStats.put("cancelled", cancelled);
            stats.put("statusStats", statusStats);

            List<Booking> upcoming = userBookings.stream()
                    .filter(b -> "已预订".equals(b.getStatus()) && b.getCheckInDate() != null && b.getCheckInDate().after(new Date()))
                    .collect(Collectors.toList());
            stats.put("upcomingCount", upcoming.size());
        }

        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("stats", stats);
        return ResponseEntity.ok(r);
    }
}

