package com.hotel.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.hotel.model.LoginRequest;
import com.hotel.model.RegisterRequest;
import com.hotel.model.User;
import com.hotel.service.ServiceResult;
import com.hotel.service.UserService;
import com.hotel.util.SecurityUtil;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/user")
public class UserController {

    private final UserService userService;

    public UserController(UserService userService) {
        this.userService = userService;
    }

    @PostMapping("/register")
    public ResponseEntity<Map<String, Object>> register(
            @RequestBody RegisterRequest registerRequest,
            HttpSession session) {

        String username = SecurityUtil.sanitizeInput(registerRequest.getUsername());
        String password = registerRequest.getPassword();
        String confirmPassword = registerRequest.getConfirmPassword();
        String fullName = SecurityUtil.sanitizeInput(registerRequest.getFullName());
        String email = SecurityUtil.sanitizeInput(registerRequest.getEmail());
        String phone = SecurityUtil.sanitizeInput(registerRequest.getPhone());
        String address = SecurityUtil.sanitizeInput(registerRequest.getAddress());

        Map<String, String> errors = new HashMap<>();

        if (username == null || username.isEmpty()) {
            errors.put("username", "用户名不能为空");
        }
        if (password == null || password.isEmpty()) {
            errors.put("password", "密码不能为空");
        }
        if (confirmPassword == null || !confirmPassword.equals(password)) {
            errors.put("confirmPassword", "两次密码不一致");
        }
        if (fullName == null || fullName.isEmpty()) {
            errors.put("fullName", "姓名不能为空");
        }
        if (email == null || email.isEmpty()) {
            errors.put("email", "邮箱不能为空");
        } else if (!SecurityUtil.isValidEmail(email)) {
            errors.put("email", "邮箱格式不正确");
        }
        if (phone != null && !phone.isEmpty() && !SecurityUtil.isValidPhone(phone)) {
            errors.put("phone", "手机号格式不正确");
        }

        if (!errors.isEmpty()) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        User user = new User();
        user.setUsername(username);
        user.setPassword(password);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddress(address);
        user.setRegistrationDate(new Date());
        user.setAdmin(false);

        ServiceResult<User> serviceResult = userService.register(user);

        if (serviceResult.isSuccess()) {
            User registeredUser = serviceResult.getData();
            registeredUser.setPassword(null);
            session.setAttribute("user", registeredUser);
            session.setAttribute("userId", registeredUser.getId());
            session.setAttribute("username", registeredUser.getUsername());
            session.setAttribute("isAdmin", registeredUser.isAdmin());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", serviceResult.getMessage());
            response.put("user", registeredUser);
            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", serviceResult.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(
            @RequestBody LoginRequest loginRequest,
            HttpSession session) {

        String username = SecurityUtil.sanitizeInput(loginRequest.getUsername());
        String password = loginRequest.getPassword();

        Map<String, String> errors = new HashMap<>();
        if (username == null || username.isEmpty()) {
            errors.put("username", "用户名不能为空");
        }
        if (password == null || password.isEmpty()) {
            errors.put("password", "密码不能为空");
        }
        if (!errors.isEmpty()) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        ServiceResult<User> serviceResult = userService.login(username, password);

        if (serviceResult.isSuccess()) {
            User loggedInUser = serviceResult.getData();
            loggedInUser.setPassword(null);
            session.setAttribute("user", loggedInUser);
            session.setAttribute("userId", loggedInUser.getId());
            session.setAttribute("username", loggedInUser.getUsername());
            session.setAttribute("isAdmin", loggedInUser.isAdmin());

            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", serviceResult.getMessage());
            response.put("user", loggedInUser);
            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", serviceResult.getMessage());
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }
    }

    @GetMapping("/logout")
    public Map<String, Object> logout(HttpSession session) {
        if (session != null) {
            session.invalidate();
        }
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "注销成功");
        return response;
    }

    @GetMapping("/profile")
    public ResponseEntity<Map<String, Object>> getUserProfile(
            @RequestParam(value = "id", required = false) Integer id,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }

        int currentUserId = (int) session.getAttribute("userId");
        boolean isAdmin = session.getAttribute("isAdmin") != null && (boolean) session.getAttribute("isAdmin");

        int userId;
        if (id != null && isAdmin) {
            userId = id;
        } else {
            userId = currentUserId;
        }

        User user = userService.getUserById(userId);
        if (user == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "用户不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        user.setPassword(null);
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("user", user);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/update")
    public ResponseEntity<Map<String, Object>> updateProfile(
            @RequestParam(value = "id", required = false) Integer id,
            @RequestParam String username,
            @RequestParam String fullName,
            @RequestParam String email,
            @RequestParam(required = false) String phone,
            @RequestParam(required = false) String address,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }

        int currentUserId = (int) session.getAttribute("userId");
        boolean isAdmin = session.getAttribute("isAdmin") != null && (boolean) session.getAttribute("isAdmin");

        int userId;
        if (id != null && isAdmin) {
            userId = id;
        } else {
            userId = currentUserId;
        }

        User user = userService.getUserById(userId);
        if (user == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "用户不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(response);
        }

        if (!isAdmin && userId != currentUserId) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "您没有权限修改此用户信息");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        }

        username = SecurityUtil.sanitizeInput(username);
        fullName = SecurityUtil.sanitizeInput(fullName);
        email = SecurityUtil.sanitizeInput(email);
        phone = SecurityUtil.sanitizeInput(phone);
        address = SecurityUtil.sanitizeInput(address);

        Map<String, String> errors = new HashMap<>();
        if (username == null || username.isEmpty()) {
            errors.put("username", "用户名不能为空");
        }
        if (fullName == null || fullName.isEmpty()) {
            errors.put("fullName", "姓名不能为空");
        }
        if (email == null || email.isEmpty()) {
            errors.put("email", "邮箱不能为空");
        } else if (!SecurityUtil.isValidEmail(email)) {
            errors.put("email", "邮箱格式不正确");
        }
        if (phone != null && !phone.isEmpty() && !SecurityUtil.isValidPhone(phone)) {
            errors.put("phone", "手机号格式不正确");
        }

        if (!errors.isEmpty()) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        user.setUsername(username);
        user.setFullName(fullName);
        user.setEmail(email);
        user.setPhone(phone);
        user.setAddress(address);

        ServiceResult<Boolean> result = userService.updateUser(user);

        if (result.isSuccess()) {
            if (userId == currentUserId) {
                user.setPassword(null);
                session.setAttribute("user", user);
                session.setAttribute("username", user.getUsername());
            }
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", result.getMessage());
            response.put("user", user);
            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @PostMapping("/updatePassword")
    public ResponseEntity<Map<String, Object>> updatePassword(
            @RequestBody Map<String, String> passwordData,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "请先登录");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body(response);
        }

        int userId = (int) session.getAttribute("userId");
        String oldPassword = passwordData.get("oldPassword");
        String newPassword = passwordData.get("newPassword");
        String confirmPassword = passwordData.get("confirmPassword");

        Map<String, String> errors = new HashMap<>();
        if (oldPassword == null || oldPassword.isEmpty()) {
            errors.put("oldPassword", "原密码不能为空");
        }
        if (newPassword == null || newPassword.isEmpty()) {
            errors.put("newPassword", "新密码不能为空");
        }
        if (confirmPassword == null || !confirmPassword.equals(newPassword)) {
            errors.put("confirmPassword", "两次密码不一致");
        }

        if (!errors.isEmpty()) {
            Map<String, Object> result = new HashMap<>();
            result.put("success", false);
            result.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(result);
        }

        ServiceResult<Boolean> result = userService.updatePassword(userId, oldPassword, newPassword);

        if (result.isSuccess()) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", result.getMessage());
            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }

    @GetMapping("/checkUsername")
    public ResponseEntity<Map<String, Object>> checkUsername(@RequestParam String username) {
        username = SecurityUtil.sanitizeInput(username);
        if (username == null || username.isEmpty()) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "用户名不能为空");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
        boolean exists = userService.isUsernameExists(username);
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("exists", exists);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/checkEmail")
    public ResponseEntity<Map<String, Object>> checkEmail(@RequestParam String email) {
        email = SecurityUtil.sanitizeInput(email);
        if (email == null || email.isEmpty()) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "邮箱不能为空");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
        boolean exists = userService.isEmailExists(email);
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("exists", exists);
        return ResponseEntity.ok(response);
    }

    @GetMapping("/list")
    public ResponseEntity<Map<String, Object>> listUsers(
            @RequestParam(required = false) String username,
            @RequestParam(required = false) String email,
            @RequestParam(required = false) String isAdmin,
            HttpSession session) {

        if (session == null || session.getAttribute("isAdmin") == null || !(Boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "权限不足");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        }

        List<User> users = userService.getAllUsers();

        if ((username != null && !username.isEmpty()) ||
            (email != null && !email.isEmpty()) ||
            (isAdmin != null && !isAdmin.isEmpty())) {

            users = users.stream().filter(user -> {
                boolean match = true;
                if (username != null && !username.isEmpty()) {
                    match = match && user.getUsername() != null &&
                            user.getUsername().toLowerCase().contains(username.toLowerCase());
                }
                if (email != null && !email.isEmpty()) {
                    match = match && user.getEmail() != null &&
                            user.getEmail().toLowerCase().contains(email.toLowerCase());
                }
                if (isAdmin != null && !isAdmin.isEmpty()) {
                    boolean adminFlag = Boolean.parseBoolean(isAdmin);
                    match = match && user.isAdmin() == adminFlag;
                }
                return match;
            }).collect(Collectors.toList());
        }

        users.forEach(u -> u.setPassword(null));
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("users", users);
        return ResponseEntity.ok(response);
    }

    @PostMapping("/delete")
    public ResponseEntity<Map<String, Object>> deleteUser(
            @RequestParam("id") Integer id,
            HttpSession session) {

        if (session == null || session.getAttribute("isAdmin") == null || !(Boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "权限不足");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(response);
        }

        if (id == null) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "用户ID不能为空");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        int currentUserId = (int) session.getAttribute("userId");
        if (id == currentUserId) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", "不能删除自己的账户");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }

        ServiceResult<Boolean> result = userService.deleteUser(id);

        if (result.isSuccess()) {
            Map<String, Object> response = new HashMap<>();
            response.put("success", true);
            response.put("message", "用户删除成功");
            return ResponseEntity.ok(response);
        } else {
            Map<String, Object> response = new HashMap<>();
            response.put("success", false);
            response.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(response);
        }
    }
}

