package com.hotel.controller;

import com.hotel.model.Room;
import com.hotel.service.RoomService;
import com.hotel.service.ServiceResult;
import com.hotel.util.SecurityUtil;
import jakarta.servlet.http.HttpSession;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.math.BigDecimal;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@RestController
@RequestMapping("/room")
public class RoomController {

    private final RoomService roomService;

    public RoomController(RoomService roomService) {
        this.roomService = roomService;
    }

    @GetMapping("/list")
    public Map<String, Object> listRooms(
            @RequestParam(required = false) String roomNumber,
            @RequestParam(required = false) String roomType,
            @RequestParam(required = false) String status) {

        roomNumber = SecurityUtil.sanitizeInput(roomNumber);
        roomType = SecurityUtil.sanitizeInput(roomType);
        status = SecurityUtil.sanitizeInput(status);

        List<Room> rooms = roomService.getAllRooms();

        if ((roomNumber != null && !roomNumber.isEmpty())
                || (roomType != null && !roomType.isEmpty())
                || (status != null && !status.isEmpty())) {
            List<Room> filtered = new ArrayList<>();
            for (Room r : rooms) {
                if (roomNumber != null && !roomNumber.isEmpty()) {
                    if (r.getRoomNumber() == null || !r.getRoomNumber().toLowerCase().contains(roomNumber.toLowerCase())) {
                        continue;
                    }
                }
                if (roomType != null && !roomType.isEmpty()) {
                    if (r.getRoomType() == null || !r.getRoomType().equals(roomType)) {
                        continue;
                    }
                }
                if (status != null && !status.isEmpty()) {
                    if (r.getStatus() == null || !r.getStatus().equals(status)) {
                        continue;
                    }
                }
                filtered.add(r);
            }
            rooms = filtered;
        }

        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("rooms", rooms);
        return response;
    }

    @GetMapping("/detail/{id}")
    public ResponseEntity<Map<String, Object>> getRoomDetail(@PathVariable("id") Integer id) {
        if (id == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "房间ID不能为空");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
        Room room = roomService.getRoomById(id);
        if (room == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "房间不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(r);
        }
        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("room", room);
        return ResponseEntity.ok(r);
    }

    @GetMapping("/detail")
    public ResponseEntity<Map<String, Object>> getRoomDetailByParam(@RequestParam("id") Integer id) {
        return getRoomDetail(id);
    }

    @GetMapping("/available")
    public ResponseEntity<Map<String, Object>> getAvailableRooms(
            @RequestParam(required = false) String checkInDate,
            @RequestParam(required = false) String checkOutDate) {

        if (checkInDate == null || checkInDate.isEmpty() || checkOutDate == null || checkOutDate.isEmpty()) {
            List<Room> availableRooms = roomService.getAvailableRooms();
            Map<String, Object> r = new HashMap<>();
            r.put("success", true);
            r.put("rooms", availableRooms);
            return ResponseEntity.ok(r);
        }

        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");
        Date inDate;
        Date outDate;
        try {
            inDate = df.parse(checkInDate);
            outDate = df.parse(checkOutDate);
        } catch (ParseException e) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "无效的日期格式，请使用yyyy-MM-dd格式");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        if (inDate.after(outDate)) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "入住日期不能晚于退房日期");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        List<Room> rooms = roomService.getAvailableRoomsByDateRange(inDate, outDate);
        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("rooms", rooms);
        return ResponseEntity.ok(r);
    }

    @GetMapping("/search")
    public Map<String, Object> searchRooms(
            @RequestParam(required = false) String keyword,
            @RequestParam(required = false) String roomType,
            @RequestParam(required = false) String minPrice,
            @RequestParam(required = false) String maxPrice,
            @RequestParam(required = false) String capacity) {

        keyword = SecurityUtil.sanitizeInput(keyword);
        roomType = SecurityUtil.sanitizeInput(roomType);

        Double min = null;
        Double max = null;
        Integer cap = null;

        try {
            if (minPrice != null && !minPrice.isEmpty()) {
                min = Double.parseDouble(minPrice);
            }
            if (maxPrice != null && !maxPrice.isEmpty()) {
                max = Double.parseDouble(maxPrice);
            }
            if (capacity != null && !capacity.isEmpty()) {
                cap = Integer.parseInt(capacity);
            }
        } catch (NumberFormatException e) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "无效的价格或容量");
            return r;
        }

        List<Room> rooms = roomService.searchRooms(keyword, roomType, min, max, cap);
        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("rooms", rooms);
        return r;
    }

    @GetMapping("/recommended")
    public Map<String, Object> getRecommendedRooms() {
        List<Room> availableRooms = roomService.getAvailableRooms();
        List<Room> recommended = new ArrayList<>();
        if (!availableRooms.isEmpty()) {
            Collections.shuffle(availableRooms);
            recommended = availableRooms.subList(0, Math.min(3, availableRooms.size()));
        }
        Map<String, Object> r = new HashMap<>();
        r.put("success", true);
        r.put("rooms", recommended);
        return r;
    }

    @PostMapping("/add")
    public ResponseEntity<Map<String, Object>> addRoom(
            @RequestParam String roomNumber,
            @RequestParam String roomType,
            @RequestParam String price,
            @RequestParam String capacity,
            @RequestParam(required = false) String available,
            @RequestParam(required = false) String description,
            @RequestParam String floor,
            @RequestParam(required = false) String imageUrl,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能添加房间");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        roomNumber = SecurityUtil.sanitizeInput(roomNumber);
        roomType = SecurityUtil.sanitizeInput(roomType);
        description = SecurityUtil.sanitizeInput(description);
        imageUrl = SecurityUtil.sanitizeInput(imageUrl);

        Map<String, String> errors = new HashMap<>();

        if (roomNumber == null || roomNumber.isEmpty()) {
            errors.put("roomNumber", "房间号不能为空");
        }
        if (roomType == null || roomType.isEmpty()) {
            errors.put("roomType", "房间类型不能为空");
        }

        BigDecimal bdPrice = null;
        try {
            bdPrice = new BigDecimal(price);
            if (bdPrice.compareTo(BigDecimal.ZERO) <= 0) {
                errors.put("price", "价格必须大于0");
            }
        } catch (Exception e) {
            errors.put("price", "无效的价格");
        }

        Integer cap;
        try {
            cap = Integer.parseInt(capacity);
            if (cap <= 0) {
                errors.put("capacity", "容量必须大于0");
            }
        } catch (Exception e) {
            cap = null;
            errors.put("capacity", "无效的容量");
        }

        Integer fl;
        try {
            fl = Integer.parseInt(floor);
            if (fl <= 0) {
                errors.put("floor", "楼层必须大于0");
            }
        } catch (Exception e) {
            fl = null;
            errors.put("floor", "无效的楼层");
        }

        boolean av = true;
        if (available != null && !available.isEmpty()) {
            av = Boolean.parseBoolean(available);
        }

        if (!errors.isEmpty()) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        Room room = new Room();
        room.setRoomNumber(roomNumber);
        room.setRoomType(roomType);
        room.setPrice(bdPrice);
        room.setCapacity(cap);
        room.setAvailable(av);
        room.setDescription(description);
        room.setImageUrl(imageUrl);
        room.setFloor(fl);
        room.setStatus("可用");

        ServiceResult<Room> result = roomService.addRoom(room);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            r.put("room", result.getData());
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @PostMapping("/update")
    public ResponseEntity<Map<String, Object>> updateRoom(
            @RequestParam("id") Integer id,
            @RequestParam String roomNumber,
            @RequestParam String roomType,
            @RequestParam String price,
            @RequestParam String capacity,
            @RequestParam(required = false) String available,
            @RequestParam(required = false) String description,
            @RequestParam String floor,
            @RequestParam(required = false) String status,
            @RequestParam(required = false) String imageUrl,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能更新房间");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        Map<String, String> errors = new HashMap<>();
        if (id == null) {
            errors.put("id", "房间ID不能为空");
        }

        roomNumber = SecurityUtil.sanitizeInput(roomNumber);
        roomType = SecurityUtil.sanitizeInput(roomType);
        description = SecurityUtil.sanitizeInput(description);
        status = SecurityUtil.sanitizeInput(status);
        imageUrl = SecurityUtil.sanitizeInput(imageUrl);

        if (roomNumber == null || roomNumber.isEmpty()) {
            errors.put("roomNumber", "房间号不能为空");
        }
        if (roomType == null || roomType.isEmpty()) {
            errors.put("roomType", "房间类型不能为空");
        }

        BigDecimal bdPrice = null;
        try {
            bdPrice = new BigDecimal(price);
            if (bdPrice.compareTo(BigDecimal.ZERO) <= 0) {
                errors.put("price", "价格必须大于0");
            }
        } catch (Exception e) {
            errors.put("price", "无效的价格");
        }

        Integer cap;
        try {
            cap = Integer.parseInt(capacity);
            if (cap <= 0) {
                errors.put("capacity", "容量必须大于0");
            }
        } catch (Exception e) {
            cap = null;
            errors.put("capacity", "无效的容量");
        }

        Integer fl;
        try {
            fl = Integer.parseInt(floor);
            if (fl <= 0) {
                errors.put("floor", "楼层必须大于0");
            }
        } catch (Exception e) {
            fl = null;
            errors.put("floor", "无效的楼层");
        }

        boolean av = true;
        if (available != null && !available.isEmpty()) {
            av = Boolean.parseBoolean(available);
        }

        if (status == null || status.isEmpty()) {
            status = "可用";
        }

        if (!errors.isEmpty()) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("errors", errors);
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        Room room = roomService.getRoomById(id);
        if (room == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "房间不存在");
            return ResponseEntity.status(HttpStatus.NOT_FOUND).body(r);
        }

        room.setRoomNumber(roomNumber);
        room.setRoomType(roomType);
        room.setPrice(bdPrice);
        room.setCapacity(cap);
        room.setAvailable(av);
        room.setDescription(description);
        room.setFloor(fl);
        room.setStatus(status);
        if (imageUrl != null && !imageUrl.isEmpty()) {
            room.setImageUrl(imageUrl);
        }

        ServiceResult<Boolean> result = roomService.updateRoom(room);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            r.put("room", room);
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @PostMapping("/delete")
    public ResponseEntity<Map<String, Object>> deleteRoom(@RequestParam("id") Integer id, HttpSession session) {
        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能删除房间");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        if (id == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "房间ID不能为空");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        ServiceResult<Boolean> result = roomService.deleteRoom(id);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }

    @PostMapping("/updateStatus")
    public ResponseEntity<Map<String, Object>> updateRoomStatus(
            @RequestParam("id") Integer id,
            @RequestParam("status") String status,
            HttpSession session) {

        if (session == null || session.getAttribute("userId") == null || !(boolean) session.getAttribute("isAdmin")) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "只有管理员才能更新房间状态");
            return ResponseEntity.status(HttpStatus.FORBIDDEN).body(r);
        }

        if (id == null) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "房间ID不能为空");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        status = SecurityUtil.sanitizeInput(status);
        if (status == null || status.isEmpty()) {
            Map<String, Object> r = new HashMap<>();
            r.put("success", false);
            r.put("message", "状态不能为空");
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }

        ServiceResult<Boolean> result = roomService.updateRoomStatus(id, status);
        Map<String, Object> r = new HashMap<>();
        if (result.isSuccess()) {
            r.put("success", true);
            r.put("message", result.getMessage());
            return ResponseEntity.ok(r);
        } else {
            r.put("success", false);
            r.put("message", result.getMessage());
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(r);
        }
    }
}

