package com.hotel.service.impl;

import com.hotel.dao.BookingDAO;
import com.hotel.dao.RoomDAO;
import com.hotel.dao.UserDAO;
import com.hotel.model.Booking;
import com.hotel.model.Room;
import com.hotel.model.User;
import com.hotel.service.BookingService;
import com.hotel.service.ServiceResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

@Service
public class BookingServiceImpl implements BookingService {
    private static final Logger logger = LogManager.getLogger(BookingServiceImpl.class);
    private final BookingDAO bookingDAO;
    private final RoomDAO roomDAO;
    private final UserDAO userDAO;
    
    public BookingServiceImpl(BookingDAO bookingDAO, RoomDAO roomDAO, UserDAO userDAO) {
        this.bookingDAO = bookingDAO;
        this.roomDAO = roomDAO;
        this.userDAO = userDAO;
    }

    @Override
    public ServiceResult<Booking> createBooking(Booking booking) {
        // 验证用户是否存在
        User user = userDAO.getUserById(booking.getUserId());
        if (user == null) {
            return ServiceResult.failure("用户不存在");
        }
        
        // 验证房间是否存在
        Room room = roomDAO.getRoomById(booking.getRoomId());
        if (room == null) {
            return ServiceResult.failure("房间不存在");
        }
        
        // 验证房间是否可用
        if (!room.isAvailable()) {
            return ServiceResult.failure("房间不可用");
        }
        
        // 验证日期
        if (booking.getCheckInDate() == null || booking.getCheckOutDate() == null) {
            return ServiceResult.failure("入住或退房日期不能为空");
        }
        
        if (booking.getCheckInDate().after(booking.getCheckOutDate())) {
            return ServiceResult.failure("入住日期不能晚于退房日期");
        }
        
        Date today = new Date();
        if (booking.getCheckInDate().before(today)) {
            return ServiceResult.failure("入住日期不能早于今天");
        }
        
        // 检查房间在指定日期是否可预订
        if (!bookingDAO.isRoomAvailableForBooking(booking.getRoomId(), booking.getCheckInDate(), booking.getCheckOutDate())) {
            return ServiceResult.failure("该房间在所选日期已被预订");
        }
        
        // 计算总价
        if (booking.getTotalPrice() == null || booking.getTotalPrice().compareTo(BigDecimal.ZERO) <= 0) {
            BigDecimal totalPrice = calculateTotalPrice(room.getPrice(), booking.getCheckInDate(), booking.getCheckOutDate());
            booking.setTotalPrice(totalPrice);
        }
        
        // 设置预订状态和日期
        booking.setStatus("已预订");
        booking.setBookingDate(new Date());
        
        // 添加预订
        int bookingId = bookingDAO.addBooking(booking);
        
        if (bookingId > 0) {
            booking.setId(bookingId);
            
            // 设置关联对象
            booking.setUser(user);
            booking.setRoom(room);
            
            logger.info("创建预订成功，ID: " + bookingId);
            return ServiceResult.success("预订成功", booking);
        } else {
            logger.error("创建预订失败");
            return ServiceResult.failure("预订失败，请稍后重试");
        }
    }

    @Override
    public Booking getBookingById(int id) {
        return bookingDAO.getBookingById(id);
    }

    @Override
    public ServiceResult<Boolean> updateBooking(Booking booking) {
        Booking existingBooking = bookingDAO.getBookingById(booking.getId());
        
        if (existingBooking == null) {
            return ServiceResult.failure("预订不存在");
        }
        
        // 如果更改了房间或日期，需要检查可用性
        if (booking.getRoomId() != existingBooking.getRoomId() ||
                !booking.getCheckInDate().equals(existingBooking.getCheckInDate()) ||
                !booking.getCheckOutDate().equals(existingBooking.getCheckOutDate())) {
            
            // 验证日期
            if (booking.getCheckInDate().after(booking.getCheckOutDate())) {
                return ServiceResult.failure("入住日期不能晚于退房日期");
            }
            
            // 检查当前日期限制（可选，根据业务需求决定是否保留）
            // Date today = new Date();
            // if (booking.getCheckInDate().before(today)) {
            //     return ServiceResult.failure("入住日期不能早于今天");
            // }
            
            // 检查房间在指定日期是否可预订（需要排除当前订单）
            if (!bookingDAO.isRoomAvailableForBookingExcludeBookingId(booking.getRoomId(), booking.getCheckInDate(), booking.getCheckOutDate(), booking.getId())) {
                return ServiceResult.failure("该房间在所选日期已被预订");
            }
            
            // 重新计算总价
            Room room = roomDAO.getRoomById(booking.getRoomId());
            if (room != null) {
                BigDecimal totalPrice = calculateTotalPrice(room.getPrice(), booking.getCheckInDate(), booking.getCheckOutDate());
                booking.setTotalPrice(totalPrice);
            }
        }
        
        boolean success = bookingDAO.updateBooking(booking);
        
        if (success) {
            logger.info("更新预订成功，ID: " + booking.getId());
            return ServiceResult.success("更新成功", true);
        } else {
            logger.error("更新预订失败，ID: " + booking.getId());
            return ServiceResult.failure("更新失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<Boolean> cancelBooking(int bookingId) {
        Booking booking = bookingDAO.getBookingById(bookingId);
        
        if (booking == null) {
            return ServiceResult.failure("预订不存在");
        }
        
        // 如果状态已经是已取消，则直接返回成功
        if ("已取消".equals(booking.getStatus())) {
            return ServiceResult.success("预订已取消", true);
        }
        
        // 如果已经入住或退房，则不允许取消
        if ("已入住".equals(booking.getStatus()) || "已退房".equals(booking.getStatus())) {
            return ServiceResult.failure("已入住或已退房的预订不能取消");
        }
        
        boolean success = bookingDAO.updateBookingStatus(bookingId, "已取消");
        
        if (success) {
            logger.info("取消预订成功，ID: " + bookingId);
            return ServiceResult.success("取消预订成功", true);
        } else {
            logger.error("取消预订失败，ID: " + bookingId);
            return ServiceResult.failure("取消预订失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<Boolean> checkIn(int bookingId) {
        Booking booking = bookingDAO.getBookingById(bookingId);
        
        if (booking == null) {
            return ServiceResult.failure("预订不存在");
        }
        
        // 检查预订状态
        if (!"已预订".equals(booking.getStatus())) {
            return ServiceResult.failure("只有已预订状态的预订才能办理入住");
        }
        
        boolean success = bookingDAO.updateBookingStatus(bookingId, "已入住");
        
        if (success) {
            // 更新房间状态
            roomDAO.updateRoomStatus(booking.getRoomId(), "已入住");
            
            logger.info("办理入住成功，预订ID: " + bookingId);
            return ServiceResult.success("办理入住成功", true);
        } else {
            logger.error("办理入住失败，预订ID: " + bookingId);
            return ServiceResult.failure("办理入住失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<Boolean> checkOut(int bookingId) {
        Booking booking = bookingDAO.getBookingById(bookingId);
        
        if (booking == null) {
            return ServiceResult.failure("预订不存在");
        }
        
        // 检查预订状态
        if (!"已入住".equals(booking.getStatus())) {
            return ServiceResult.failure("只有已入住状态的预订才能办理退房");
        }
        
        boolean success = bookingDAO.updateBookingStatus(bookingId, "已退房");
        
        if (success) {
            // 更新房间状态
            roomDAO.updateRoomStatus(booking.getRoomId(), "可用");
            
            logger.info("办理退房成功，预订ID: " + bookingId);
            return ServiceResult.success("办理退房成功", true);
        } else {
            logger.error("办理退房失败，预订ID: " + bookingId);
            return ServiceResult.failure("办理退房失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<Boolean> deleteBooking(int id) {
        Booking booking = bookingDAO.getBookingById(id);
        
        if (booking == null) {
            return ServiceResult.failure("预订不存在");
        }
        
        boolean success = bookingDAO.deleteBooking(id);
        
        if (success) {
            logger.info("删除预订成功，ID: " + id);
            return ServiceResult.success("删除成功", true);
        } else {
            logger.error("删除预订失败，ID: " + id);
            return ServiceResult.failure("删除失败，请稍后重试");
        }
    }

    @Override
    public List<Booking> getAllBookings() {
        return bookingDAO.getAllBookings();
    }

    @Override
    public List<Booking> getUserBookings(int userId) {
        return bookingDAO.getBookingsByUserId(userId);
    }

    @Override
    public List<Booking> getRoomBookings(int roomId) {
        return bookingDAO.getBookingsByRoomId(roomId);
    }

    @Override
    public List<Booking> getBookingsByStatus(String status) {
        return bookingDAO.getBookingsByStatus(status);
    }

    @Override
    public List<Booking> getBookingsByDateRange(Date startDate, Date endDate) {
        // 验证日期
        if (startDate == null || endDate == null || startDate.after(endDate)) {
            logger.warn("无效的日期范围: " + startDate + " - " + endDate);
            return new ArrayList<>();
        }
        
        return bookingDAO.getBookingsByDateRange(startDate, endDate);
    }

    @Override
    public boolean isRoomAvailableForBooking(int roomId, Date checkInDate, Date checkOutDate) {
        // 验证日期
        if (checkInDate == null || checkOutDate == null || checkInDate.after(checkOutDate)) {
            return false;
        }
        
        return bookingDAO.isRoomAvailableForBooking(roomId, checkInDate, checkOutDate);
    }

    @Override
    public boolean isRoomAvailableForBooking(int roomId, Date checkInDate, Date checkOutDate, int excludeBookingId) {
        // 验证日期
        if (checkInDate == null || checkOutDate == null || checkInDate.after(checkOutDate)) {
            return false;
        }
        
        return bookingDAO.isRoomAvailableForBookingExcludeBookingId(roomId, checkInDate, checkOutDate, excludeBookingId);
    }

    @Override
    public List<Booking> getAllBookingsWithDetails() {
        return bookingDAO.getAllBookingsWithDetails();
    }

    @Override
    public List<Booking> getUserBookingsWithDetails(int userId) {
        return bookingDAO.getUserBookingsWithDetails(userId);
    }
    
    // 计算总价
    private BigDecimal calculateTotalPrice(BigDecimal roomPrice, Date checkInDate, Date checkOutDate) {
        // 计算入住天数
        long diffInMillies = checkOutDate.getTime() - checkInDate.getTime();
        long days = TimeUnit.DAYS.convert(diffInMillies, TimeUnit.MILLISECONDS);
        
        // 至少入住1天
        if (days < 1) {
            days = 1;
        }
        
        return roomPrice.multiply(new BigDecimal(days));
    }
} 