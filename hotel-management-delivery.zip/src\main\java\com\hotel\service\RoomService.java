package com.hotel.service;

import com.hotel.model.Room;
import java.util.Date;
import java.util.List;

public interface RoomService {
    
    /**
     * 添加新房间
     * @param room 房间信息
     * @return 添加结果，包含房间ID和状态信息
     */
    ServiceResult<Room> addRoom(Room room);
    
    /**
     * 根据ID获取房间
     * @param id 房间ID
     * @return 房间对象
     */
    Room getRoomById(int id);
    
    /**
     * 根据房间号获取房间
     * @param roomNumber 房间号
     * @return 房间对象
     */
    Room getRoomByNumber(String roomNumber);
    
    /**
     * 更新房间信息
     * @param room 房间对象
     * @return 更新结果，包含状态信息
     */
    ServiceResult<Boolean> updateRoom(Room room);
    
    /**
     * 删除房间
     * @param id 房间ID
     * @return 删除结果，包含状态信息
     */
    ServiceResult<Boolean> deleteRoom(int id);
    
    /**
     * 获取所有房间
     * @return 房间列表
     */
    List<Room> getAllRooms();
    
    /**
     * 获取可用房间
     * @return 可用房间列表
     */
    List<Room> getAvailableRooms();
    
    /**
     * 根据类型获取房间
     * @param roomType 房间类型
     * @return 房间列表
     */
    List<Room> getRoomsByType(String roomType);
    
    /**
     * 根据价格范围获取房间
     * @param minPrice 最低价格
     * @param maxPrice 最高价格
     * @return 房间列表
     */
    List<Room> getRoomsByPriceRange(double minPrice, double maxPrice);
    
    /**
     * 根据容量获取房间
     * @param capacity 容量
     * @return 房间列表
     */
    List<Room> getRoomsByCapacity(int capacity);
    
    /**
     * 获取指定日期范围内可用的房间
     * @param checkInDate 入住日期
     * @param checkOutDate 退房日期
     * @return 可用房间列表
     */
    List<Room> getAvailableRoomsByDateRange(Date checkInDate, Date checkOutDate);
    
    /**
     * 更新房间状态
     * @param roomId 房间ID
     * @param status 状态
     * @return 更新结果，包含状态信息
     */
    ServiceResult<Boolean> updateRoomStatus(int roomId, String status);
    
    /**
     * 搜索房间
     * @param keyword 关键词
     * @param roomType 房间类型
     * @param minPrice 最低价格
     * @param maxPrice 最高价格
     * @param capacity 容量
     * @return 房间列表
     */
    List<Room> searchRooms(String keyword, String roomType, Double minPrice, Double maxPrice, Integer capacity);
} 