package com.hotel.service;

import com.hotel.model.Booking;
import java.util.Date;
import java.util.List;

public interface BookingService {
    
    /**
     * 创建预订
     * @param booking 预订信息
     * @return 创建结果，包含预订ID和状态信息
     */
    ServiceResult<Booking> createBooking(Booking booking);
    
    /**
     * 根据ID获取预订
     * @param id 预订ID
     * @return 预订对象
     */
    Booking getBookingById(int id);
    
    /**
     * 更新预订信息
     * @param booking 预订对象
     * @return 更新结果，包含状态信息
     */
    ServiceResult<Boolean> updateBooking(Booking booking);
    
    /**
     * 取消预订
     * @param bookingId 预订ID
     * @return 取消结果，包含状态信息
     */
    ServiceResult<Boolean> cancelBooking(int bookingId);
    
    /**
     * 完成入住
     * @param bookingId 预订ID
     * @return 操作结果，包含状态信息
     */
    ServiceResult<Boolean> checkIn(int bookingId);
    
    /**
     * 完成退房
     * @param bookingId 预订ID
     * @return 操作结果，包含状态信息
     */
    ServiceResult<Boolean> checkOut(int bookingId);
    
    /**
     * 删除预订
     * @param id 预订ID
     * @return 删除结果，包含状态信息
     */
    ServiceResult<Boolean> deleteBooking(int id);
    
    /**
     * 获取所有预订
     * @return 预订列表
     */
    List<Booking> getAllBookings();
    
    /**
     * 获取用户的预订
     * @param userId 用户ID
     * @return 预订列表
     */
    List<Booking> getUserBookings(int userId);
    
    /**
     * 获取房间的预订
     * @param roomId 房间ID
     * @return 预订列表
     */
    List<Booking> getRoomBookings(int roomId);
    
    /**
     * 根据状态获取预订
     * @param status 状态
     * @return 预订列表
     */
    List<Booking> getBookingsByStatus(String status);
    
    /**
     * 获取指定日期范围内的预订
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 预订列表
     */
    List<Booking> getBookingsByDateRange(Date startDate, Date endDate);
    
    /**
     * 检查房间在指定日期范围内是否可预订
     * @param roomId 房间ID
     * @param checkInDate 入住日期
     * @param checkOutDate 退房日期
     * @return 如果房间可预订返回true，否则返回false
     */
    boolean isRoomAvailableForBooking(int roomId, Date checkInDate, Date checkOutDate);
    
    /**
     * 检查房间在指定日期范围内是否可预订，排除指定订单ID
     * @param roomId 房间ID
     * @param checkInDate 入住日期
     * @param checkOutDate 退房日期
     * @param excludeBookingId 要排除的订单ID（用于更新订单时）
     * @return 如果房间可预订返回true，否则返回false
     */
    boolean isRoomAvailableForBooking(int roomId, Date checkInDate, Date checkOutDate, int excludeBookingId);
    
    /**
     * 获取包含详细信息的所有预订
     * @return 预订列表
     */
    List<Booking> getAllBookingsWithDetails();
    
    /**
     * 获取包含详细信息的用户预订
     * @param userId 用户ID
     * @return 预订列表
     */
    List<Booking> getUserBookingsWithDetails(int userId);
} 