package com.hotel.service.impl;

import com.hotel.dao.RoomDAO;
import com.hotel.model.Room;
import com.hotel.service.RoomService;
import com.hotel.service.ServiceResult;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class RoomServiceImpl implements RoomService {
    private static final Logger logger = LogManager.getLogger(RoomServiceImpl.class);
    private final RoomDAO roomDAO;
    
    public RoomServiceImpl(RoomDAO roomDAO) {
        this.roomDAO = roomDAO;
    }

    @Override
    public ServiceResult<Room> addRoom(Room room) {
        // 检查房间号是否已存在
        Room existingRoom = roomDAO.getRoomByNumber(room.getRoomNumber());
        if (existingRoom != null) {
            return ServiceResult.failure("房间号已存在");
        }
        
        int roomId = roomDAO.addRoom(room);
        
        if (roomId > 0) {
            room.setId(roomId);
            logger.info("添加房间成功，房间号: " + room.getRoomNumber());
            return ServiceResult.success("添加成功", room);
        } else {
            logger.error("添加房间失败，房间号: " + room.getRoomNumber());
            return ServiceResult.failure("添加失败，请稍后重试");
        }
    }

    @Override
    public Room getRoomById(int id) {
        return roomDAO.getRoomById(id);
    }

    @Override
    public Room getRoomByNumber(String roomNumber) {
        return roomDAO.getRoomByNumber(roomNumber);
    }

    @Override
    public ServiceResult<Boolean> updateRoom(Room room) {
        Room existingRoom = roomDAO.getRoomById(room.getId());
        
        if (existingRoom == null) {
            return ServiceResult.failure("房间不存在");
        }
        
        // 检查房间号是否被其他房间使用
        if (!existingRoom.getRoomNumber().equals(room.getRoomNumber())) {
            Room roomWithSameNumber = roomDAO.getRoomByNumber(room.getRoomNumber());
            if (roomWithSameNumber != null) {
                return ServiceResult.failure("房间号已被使用");
            }
        }
        
        boolean success = roomDAO.updateRoom(room);
        
        if (success) {
            logger.info("更新房间成功，ID: " + room.getId());
            return ServiceResult.success("更新成功", true);
        } else {
            logger.error("更新房间失败，ID: " + room.getId());
            return ServiceResult.failure("更新失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<Boolean> deleteRoom(int id) {
        Room room = roomDAO.getRoomById(id);
        
        if (room == null) {
            return ServiceResult.failure("房间不存在");
        }
        
        boolean success = roomDAO.deleteRoom(id);
        
        if (success) {
            logger.info("删除房间成功，ID: " + id);
            return ServiceResult.success("删除成功", true);
        } else {
            logger.error("删除房间失败，ID: " + id);
            return ServiceResult.failure("删除失败，请稍后重试");
        }
    }

    @Override
    public List<Room> getAllRooms() {
        return roomDAO.getAllRooms();
    }

    @Override
    public List<Room> getAvailableRooms() {
        return roomDAO.getAvailableRooms();
    }

    @Override
    public List<Room> getRoomsByType(String roomType) {
        return roomDAO.getRoomsByType(roomType);
    }

    @Override
    public List<Room> getRoomsByPriceRange(double minPrice, double maxPrice) {
        return roomDAO.getRoomsByPriceRange(minPrice, maxPrice);
    }

    @Override
    public List<Room> getRoomsByCapacity(int capacity) {
        return roomDAO.getRoomsByCapacity(capacity);
    }

    @Override
    public List<Room> getAvailableRoomsByDateRange(Date checkInDate, Date checkOutDate) {
        // 验证日期
        if (checkInDate == null || checkOutDate == null || checkInDate.after(checkOutDate)) {
            logger.warn("无效的日期范围: " + checkInDate + " - " + checkOutDate);
            return new ArrayList<>();
        }
        
        return roomDAO.getAvailableRoomsByDateRange(checkInDate, checkOutDate);
    }

    @Override
    public ServiceResult<Boolean> updateRoomStatus(int roomId, String status) {
        Room room = roomDAO.getRoomById(roomId);
        
        if (room == null) {
            return ServiceResult.failure("房间不存在");
        }
        
        boolean success = roomDAO.updateRoomStatus(roomId, status);
        
        if (success) {
            logger.info("更新房间状态成功，ID: " + roomId + ", 状态: " + status);
            return ServiceResult.success("更新成功", true);
        } else {
            logger.error("更新房间状态失败，ID: " + roomId);
            return ServiceResult.failure("更新失败，请稍后重试");
        }
    }

    @Override
    public List<Room> searchRooms(String keyword, String roomType, Double minPrice, Double maxPrice, Integer capacity) {
        // 获取所有房间
        List<Room> allRooms = roomDAO.getAllRooms();
        
        // 根据条件筛选
        return allRooms.stream()
                .filter(room -> {
                    // 关键词筛选
                    if (keyword != null && !keyword.isEmpty()) {
                        String lowerKeyword = keyword.toLowerCase();
                        boolean matchesKeyword = room.getRoomNumber().toLowerCase().contains(lowerKeyword) ||
                                room.getRoomType().toLowerCase().contains(lowerKeyword) ||
                                (room.getDescription() != null && room.getDescription().toLowerCase().contains(lowerKeyword));
                        if (!matchesKeyword) {
                            return false;
                        }
                    }
                    
                    // 房间类型筛选
                    if (roomType != null && !roomType.isEmpty() && !room.getRoomType().equals(roomType)) {
                        return false;
                    }
                    
                    // 价格范围筛选
                    if (minPrice != null && room.getPrice().doubleValue() < minPrice) {
                        return false;
                    }
                    if (maxPrice != null && room.getPrice().doubleValue() > maxPrice) {
                        return false;
                    }
                    
                    // 容量筛选
                    if (capacity != null && room.getCapacity() < capacity) {
                        return false;
                    }
                    
                    return true;
                })
                .collect(Collectors.toList());
    }
} 