package com.hotel.model;

import java.math.BigDecimal;

public class Room {
    private int id;
    private String roomNumber;
    private String roomType;
    private BigDecimal price;
    private int capacity;
    private boolean available;
    private String description;
    private String imageUrl;
    private int floor;
    private String status; // 可用、维修中、已预订等

    public Room() {
    }

    public Room(String roomNumber, String roomType, BigDecimal price, int capacity, boolean available, String description, String imageUrl, int floor) {
        this.roomNumber = roomNumber;
        this.roomType = roomType;
        this.price = price;
        this.capacity = capacity;
        this.available = available;
        this.description = description;
        this.imageUrl = imageUrl;
        this.floor = floor;
        this.status = "可用";
    }

    // Getters and Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getRoomNumber() {
        return roomNumber;
    }

    public void setRoomNumber(String roomNumber) {
        this.roomNumber = roomNumber;
    }

    public String getRoomType() {
        return roomType;
    }

    public void setRoomType(String roomType) {
        this.roomType = roomType;
    }

    public BigDecimal getPrice() {
        return price;
    }

    public void setPrice(BigDecimal price) {
        this.price = price;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public boolean isAvailable() {
        return available;
    }

    public void setAvailable(boolean available) {
        this.available = available;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getImageUrl() {
        return imageUrl;
    }

    public void setImageUrl(String imageUrl) {
        this.imageUrl = imageUrl;
    }

    public int getFloor() {
        return floor;
    }

    public void setFloor(int floor) {
        this.floor = floor;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return "Room{" +
                "id=" + id +
                ", roomNumber='" + roomNumber + '\'' +
                ", roomType='" + roomType + '\'' +
                ", price=" + price +
                ", capacity=" + capacity +
                ", available=" + available +
                ", description='" + description + '\'' +
                ", imageUrl='" + imageUrl + '\'' +
                ", floor=" + floor +
                ", status='" + status + '\'' +
                '}';
    }
} 