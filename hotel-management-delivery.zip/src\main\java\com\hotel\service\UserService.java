package com.hotel.service;

import com.hotel.model.User;
import java.util.List;

public interface UserService {
    
    /**
     * 用户注册
     * @param user 用户信息
     * @return 注册结果，包含用户ID和状态信息
     */
    ServiceResult<User> register(User user);
    
    /**
     * 用户登录
     * @param username 用户名
     * @param password 密码
     * @return 登录结果，包含用户对象和状态信息
     */
    ServiceResult<User> login(String username, String password);
    
    /**
     * 根据ID获取用户
     * @param id 用户ID
     * @return 用户对象
     */
    User getUserById(int id);
    
    /**
     * 根据用户名获取用户
     * @param username 用户名
     * @return 用户对象
     */
    User getUserByUsername(String username);
    
    /**
     * 更新用户信息
     * @param user 用户对象
     * @return 更新结果，包含状态信息
     */
    ServiceResult<Boolean> updateUser(User user);
    
    /**
     * 更新用户密码
     * @param userId 用户ID
     * @param oldPassword 旧密码
     * @param newPassword 新密码
     * @return 更新结果，包含状态信息
     */
    ServiceResult<Boolean> updatePassword(int userId, String oldPassword, String newPassword);
    
    /**
     * 删除用户
     * @param id 用户ID
     * @return 删除结果，包含状态信息
     */
    ServiceResult<Boolean> deleteUser(int id);
    
    /**
     * 获取所有用户
     * @return 用户列表
     */
    List<User> getAllUsers();
    
    /**
     * 检查用户名是否已存在
     * @param username 用户名
     * @return 是否存在
     */
    boolean isUsernameExists(String username);
    
    /**
     * 检查邮箱是否已存在
     * @param email 邮箱
     * @return 是否存在
     */
    boolean isEmailExists(String email);
} 