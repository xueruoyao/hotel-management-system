package com.hotel;

import com.hotel.config.DatabaseInitializer;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@MapperScan("com.hotel.dao")
public class HotelManagementApplication implements CommandLineRunner {

    @Autowired
    private DatabaseInitializer databaseInitializer;

    public static void main(String[] args) {
        SpringApplication.run(HotelManagementApplication.class, args);
    }

    @Override
    public void run(String... args) throws Exception {
        // 初始化数据库
        databaseInitializer.initialize();
    }
}

