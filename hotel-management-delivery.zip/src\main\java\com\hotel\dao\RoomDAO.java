package com.hotel.dao;

import com.hotel.model.Room;
import java.util.List;
import java.util.Date;

public interface RoomDAO {
    
    /**
     * 添加新房间
     * @param room 房间对象
     * @return 新增房间的ID
     */
    int addRoom(Room room);
    
    /**
     * 根据ID查询房间
     * @param id 房间ID
     * @return 房间对象
     */
    Room getRoomById(int id);
    
    /**
     * 根据房间号查询房间
     * @param roomNumber 房间号
     * @return 房间对象
     */
    Room getRoomByNumber(String roomNumber);
    
    /**
     * 更新房间信息
     * @param room 房间对象
     * @return 是否更新成功
     */
    boolean updateRoom(Room room);
    
    /**
     * 删除房间
     * @param id 房间ID
     * @return 是否删除成功
     */
    boolean deleteRoom(int id);
    
    /**
     * 查询所有房间
     * @return 房间列表
     */
    List<Room> getAllRooms();
    
    /**
     * 查询可用房间
     * @return 可用房间列表
     */
    List<Room> getAvailableRooms();
    
    /**
     * 根据类型查询房间
     * @param roomType 房间类型
     * @return 房间列表
     */
    List<Room> getRoomsByType(String roomType);
    
    /**
     * 根据价格范围查询房间
     * @param minPrice 最低价格
     * @param maxPrice 最高价格
     * @return 房间列表
     */
    List<Room> getRoomsByPriceRange(double minPrice, double maxPrice);
    
    /**
     * 根据容量查询房间
     * @param capacity 容量
     * @return 房间列表
     */
    List<Room> getRoomsByCapacity(int capacity);
    
    /**
     * 查询指定日期范围内可用的房间
     * @param checkInDate 入住日期
     * @param checkOutDate 退房日期
     * @return 可用房间列表
     */
    List<Room> getAvailableRoomsByDateRange(Date checkInDate, Date checkOutDate);
    
    /**
     * 更新房间状态
     * @param roomId 房间ID
     * @param status 状态
     * @return 是否更新成功
     */
    boolean updateRoomStatus(int roomId, String status);
} 