package com.hotel.util;

import org.apache.commons.text.StringEscapeUtils;
import org.mindrot.jbcrypt.BCrypt;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;

import java.util.regex.Pattern;

public class SecurityUtil {
    private static final Logger logger = LogManager.getLogger(SecurityUtil.class);
    
    // 密码加密
    public static String hashPassword(String plainPassword) {
        return BCrypt.hashpw(plainPassword, BCrypt.gensalt(12));
    }
    
    // 密码验证
    public static boolean checkPassword(String plainPassword, String hashedPassword) {
        return BCrypt.checkpw(plainPassword, hashedPassword);
    }
    
    // 防止XSS攻击，HTML转义
    public static String escapeHtml(String input) {
        if (input == null) {
            return null;
        }
        return StringEscapeUtils.escapeHtml4(input);
    }
    
    // 防止SQL注入，验证输入是否包含SQL注入攻击
    public static boolean isSqlInjectionSafe(String input) {
        if (input == null) {
            return true;
        }
        
        // SQL注入检测正则表达式
        String sqlInjectionPattern = "('(''|[^'])*')|"
                + "(;)|"
                + "(--)|"
                + "(/\\*.*?\\*/)|"
                + "(\\b(select|update|delete|insert|drop|alter|create|rename|truncate|desc|describe|union|into|load_file|outfile)\\b)";
        
        Pattern pattern = Pattern.compile(sqlInjectionPattern, Pattern.CASE_INSENSITIVE);
        return !pattern.matcher(input).find();
    }
    
    // 清理输入，防止XSS和SQL注入
    public static String sanitizeInput(String input) {
        if (input == null) {
            return null;
        }
        
        // 检查SQL注入
        if (!isSqlInjectionSafe(input)) {
            logger.warn("检测到可能的SQL注入攻击: " + input);
            return "";
        }
        
        // HTML转义防止XSS
        return escapeHtml(input);
    }
    
    // 验证邮箱格式
    public static boolean isValidEmail(String email) {
        if (email == null || email.isEmpty()) {
            return false;
        }
        String emailRegex = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$";
        Pattern pattern = Pattern.compile(emailRegex);
        return pattern.matcher(email).matches();
    }
    
    // 验证手机号格式（中国大陆手机号）
    public static boolean isValidPhone(String phone) {
        if (phone == null || phone.isEmpty()) {
            return false;
        }
        String phoneRegex = "^1[3-9]\\d{9}$";
        Pattern pattern = Pattern.compile(phoneRegex);
        return pattern.matcher(phone).matches();
    }
} 