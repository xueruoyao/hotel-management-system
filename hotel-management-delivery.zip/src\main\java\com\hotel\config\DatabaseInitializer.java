package com.hotel.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.ClassPathResource;
import org.springframework.jdbc.datasource.init.ResourceDatabasePopulator;
import org.springframework.stereotype.Component;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

@Component
public class DatabaseInitializer {

    @Autowired
    private DataSource dataSource;

    public void initialize() {
        // 首先创建数据库（如果不存在）
        createDatabaseIfNotExists();
        
        // 然后初始化表结构和数据
        initializeSchema();
    }

    private void createDatabaseIfNotExists() {
        String url = "jdbc:mysql://localhost:3306/";
        String username = "root";
        String password = "8254503";
        String databaseName = "hotel_db";

        try (Connection connection = DriverManager.getConnection(url, username, password);
             Statement statement = connection.createStatement()) {
            // 创建数据库（如果不存在）
            String createDbSql = "CREATE DATABASE IF NOT EXISTS " + databaseName + " CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci";
            statement.executeUpdate(createDbSql);
            System.out.println("Database created or already exists: " + databaseName);
        } catch (SQLException e) {
            System.err.println("Error creating database: " + e.getMessage());
        }
    }

    private void initializeSchema() {
        try {
            // 使用ResourceDatabasePopulator来执行SQL脚本
            ResourceDatabasePopulator populator = new ResourceDatabasePopulator();
            populator.addScript(new ClassPathResource("hotel_db.sql"));
            populator.execute(dataSource);
            System.out.println("Database schema initialized successfully");
        } catch (Exception e) {
            System.err.println("Error initializing database schema: " + e.getMessage());
        }
    }
}
