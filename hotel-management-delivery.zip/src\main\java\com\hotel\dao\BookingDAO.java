package com.hotel.dao;

import com.hotel.model.Booking;
import java.util.Date;
import java.util.List;

public interface BookingDAO {
    
    /**
     * 添加新预订
     * @param booking 预订对象
     * @return 新增预订的ID
     */
    int addBooking(Booking booking);
    
    /**
     * 根据ID查询预订
     * @param id 预订ID
     * @return 预订对象
     */
    Booking getBookingById(int id);
    
    /**
     * 更新预订信息
     * @param booking 预订对象
     * @return 是否更新成功
     */
    boolean updateBooking(Booking booking);
    
    /**
     * 删除预订
     * @param id 预订ID
     * @return 是否删除成功
     */
    boolean deleteBooking(int id);
    
    /**
     * 查询所有预订
     * @return 预订列表
     */
    List<Booking> getAllBookings();
    
    /**
     * 根据用户ID查询预订
     * @param userId 用户ID
     * @return 预订列表
     */
    List<Booking> getBookingsByUserId(int userId);
    
    /**
     * 根据房间ID查询预订
     * @param roomId 房间ID
     * @return 预订列表
     */
    List<Booking> getBookingsByRoomId(int roomId);
    
    /**
     * 根据状态查询预订
     * @param status 状态
     * @return 预订列表
     */
    List<Booking> getBookingsByStatus(String status);
    
    /**
     * 查询指定日期范围内的预订
     * @param startDate 开始日期
     * @param endDate 结束日期
     * @return 预订列表
     */
    List<Booking> getBookingsByDateRange(Date startDate, Date endDate);
    
    /**
     * 更新预订状态
     * @param bookingId 预订ID
     * @param status 状态
     * @return 是否更新成功
     */
    boolean updateBookingStatus(int bookingId, String status);
    
    /**
     * 检查房间在指定日期范围内是否可预订
     * @param roomId 房间ID
     * @param checkInDate 入住日期
     * @param checkOutDate 退房日期
     * @return 如果房间可预订返回true，否则返回false
     */
    boolean isRoomAvailableForBooking(int roomId, Date checkInDate, Date checkOutDate);
    
    /**
     * 检查房间在指定日期范围内是否可预订，排除指定订单ID
     * @param roomId 房间ID
     * @param checkInDate 入住日期
     * @param checkOutDate 退房日期
     * @param excludeBookingId 要排除的订单ID（用于更新订单时）
     * @return 如果房间可预订返回true，否则返回false
     */
    boolean isRoomAvailableForBookingExcludeBookingId(int roomId, Date checkInDate, Date checkOutDate, int excludeBookingId);
    
    /**
     * 获取包含用户和房间信息的预订列表
     * @return 预订列表
     */
    List<Booking> getAllBookingsWithDetails();
    
    /**
     * 根据用户ID获取包含房间信息的预订列表
     * @param userId 用户ID
     * @return 预订列表
     */
    List<Booking> getUserBookingsWithDetails(int userId);
} 