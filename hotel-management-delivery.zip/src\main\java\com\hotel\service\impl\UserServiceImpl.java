package com.hotel.service.impl;

import com.hotel.dao.UserDAO;
import com.hotel.model.User;
import com.hotel.service.ServiceResult;
import com.hotel.service.UserService;
import com.hotel.util.SecurityUtil;
import org.apache.logging.log4j.LogManager;
import org.apache.logging.log4j.Logger;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImpl implements UserService {
    private static final Logger logger = LogManager.getLogger(UserServiceImpl.class);
    private final UserDAO userDAO;
    
    public UserServiceImpl(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    @Override
    public ServiceResult<User> register(User user) {
        // 验证用户名和邮箱是否已存在
        if (userDAO.isUsernameExists(user.getUsername())) {
            return ServiceResult.failure("用户名已存在");
        }
        
        if (userDAO.isEmailExists(user.getEmail())) {
            return ServiceResult.failure("邮箱已存在");
        }
        
        // 验证邮箱格式
        if (!SecurityUtil.isValidEmail(user.getEmail())) {
            return ServiceResult.failure("邮箱格式不正确");
        }
        
        // 验证手机号格式
        if (user.getPhone() != null && !user.getPhone().isEmpty() && !SecurityUtil.isValidPhone(user.getPhone())) {
            return ServiceResult.failure("手机号格式不正确");
        }
        
        // 加密密码
        String hashedPassword = SecurityUtil.hashPassword(user.getPassword());
        user.setPassword(hashedPassword);
        
        // 添加用户
        int userId = userDAO.addUser(user);
        
        if (userId > 0) {
            user.setId(userId);
            logger.info("用户注册成功: " + user.getUsername());
            return ServiceResult.success("注册成功", user);
        } else {
            logger.error("用户注册失败: " + user.getUsername());
            return ServiceResult.failure("注册失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<User> login(String username, String password) {
        User user = userDAO.getUserByUsername(username);
        
        if (user == null) {
            logger.warn("登录失败，用户名不存在: " + username);
            return ServiceResult.failure("用户名或密码错误");
        }
        
        // 验证密码
        if (!SecurityUtil.checkPassword(password, user.getPassword())) {
            logger.warn("登录失败，密码错误: " + username);
            return ServiceResult.failure("用户名或密码错误");
        }
        
        logger.info("用户登录成功: " + username);
        return ServiceResult.success("登录成功", user);
    }

    @Override
    public User getUserById(int id) {
        return userDAO.getUserById(id);
    }

    @Override
    public User getUserByUsername(String username) {
        return userDAO.getUserByUsername(username);
    }

    @Override
    public ServiceResult<Boolean> updateUser(User user) {
        User existingUser = userDAO.getUserById(user.getId());
        
        if (existingUser == null) {
            return ServiceResult.failure("用户不存在");
        }
        
        // 检查用户名是否被其他用户使用
        if (!existingUser.getUsername().equals(user.getUsername()) && userDAO.isUsernameExists(user.getUsername())) {
            return ServiceResult.failure("用户名已存在");
        }
        
        // 检查邮箱是否被其他用户使用
        if (!existingUser.getEmail().equals(user.getEmail()) && userDAO.isEmailExists(user.getEmail())) {
            return ServiceResult.failure("邮箱已存在");
        }
        
        // 验证邮箱格式
        if (!SecurityUtil.isValidEmail(user.getEmail())) {
            return ServiceResult.failure("邮箱格式不正确");
        }
        
        // 验证手机号格式
        if (user.getPhone() != null && !user.getPhone().isEmpty() && !SecurityUtil.isValidPhone(user.getPhone())) {
            return ServiceResult.failure("手机号格式不正确");
        }
        
        // 保留原密码
        user.setPassword(existingUser.getPassword());
        
        boolean success = userDAO.updateUser(user);
        
        if (success) {
            logger.info("用户信息更新成功: " + user.getUsername());
            return ServiceResult.success("更新成功", true);
        } else {
            logger.error("用户信息更新失败: " + user.getUsername());
            return ServiceResult.failure("更新失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<Boolean> updatePassword(int userId, String oldPassword, String newPassword) {
        User user = userDAO.getUserById(userId);
        
        if (user == null) {
            return ServiceResult.failure("用户不存在");
        }
        
        // 验证旧密码
        if (!SecurityUtil.checkPassword(oldPassword, user.getPassword())) {
            return ServiceResult.failure("原密码错误");
        }
        
        // 加密新密码
        String hashedPassword = SecurityUtil.hashPassword(newPassword);
        user.setPassword(hashedPassword);
        
        boolean success = userDAO.updateUser(user);
        
        if (success) {
            logger.info("用户密码更新成功: " + user.getUsername());
            return ServiceResult.success("密码更新成功", true);
        } else {
            logger.error("用户密码更新失败: " + user.getUsername());
            return ServiceResult.failure("密码更新失败，请稍后重试");
        }
    }

    @Override
    public ServiceResult<Boolean> deleteUser(int id) {
        User user = userDAO.getUserById(id);
        
        if (user == null) {
            return ServiceResult.failure("用户不存在");
        }
        
        boolean success = userDAO.deleteUser(id);
        
        if (success) {
            logger.info("用户删除成功，ID: " + id);
            return ServiceResult.success("删除成功", true);
        } else {
            logger.error("用户删除失败，ID: " + id);
            return ServiceResult.failure("删除失败，请稍后重试");
        }
    }

    @Override
    public List<User> getAllUsers() {
        return userDAO.getAllUsers();
    }

    @Override
    public boolean isUsernameExists(String username) {
        return userDAO.isUsernameExists(username);
    }

    @Override
    public boolean isEmailExists(String email) {
        return userDAO.isEmailExists(email);
    }
} 